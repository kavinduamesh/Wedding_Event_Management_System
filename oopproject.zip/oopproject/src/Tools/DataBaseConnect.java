package Tools;

public interface DataBaseConnect {
	
	public void ConnectDB();

}
